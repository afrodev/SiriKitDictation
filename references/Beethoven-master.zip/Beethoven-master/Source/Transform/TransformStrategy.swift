public enum TransformStrategy {
  case simple
  case fft
}
